import 'package:flutter_modular/flutter_modular.dart';

class HomeController {
  int currentIndex = 0;

  void updateTabIndex(int index) {
    currentIndex = index;
    switch (index) {
      case 0:
        Modular.to.navigate('/home/');
        break;
      case 1:
        Modular.to.navigate('/spider_control/');
        break;
    }
  }
}
